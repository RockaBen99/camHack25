need to pip install:
- scipy
- numpy
- matplotlib

Need to download thinkfan on a compatible linux laptop, enable it as a daemon, and set it up to use this config